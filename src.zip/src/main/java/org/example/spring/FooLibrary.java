package org.example.spring;

public interface FooLibrary {
    double calculateProducts();
}
